from setuptools import setup

setup(name='submitter_utils_ppp_p5',
      version='1.0',
      description='Sail() submission tools',
      url='https://sailplatform.org/',
      author='Jaromir Savelka',
      author_email='jsavelka@cs.cmu.edu',
      packages=['submitter_utils', 'submitter_utils.core'],
      include_package_data=True,
      zip_safe=False)
