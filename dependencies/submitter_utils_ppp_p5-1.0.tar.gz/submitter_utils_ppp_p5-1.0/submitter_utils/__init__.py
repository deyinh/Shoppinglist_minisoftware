import sourcedefender
from submitter_utils.submitter import Submitter
from submitter_utils.tasks import TASKS


def submit(task_number, refresh_credentials):
    submitter = Submitter(task_number, TASKS, refresh_credentials)
    submitter.run()
